<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>
<style>
    body{
        background-color: #1e272e
    }

    .p-5{
        display: flex;
        justify-content: center;
        align-items: center;
        height: 800px;
    }
</style>
<body>
    <div class="container">
        <div class="row">
            <div class="p-5">
                <center>
                    <img src="<?php echo e(asset('images/pandoradev.png')); ?>" alt="" width="70px"><br>
                </center>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\LARAVEL\untuknya\resources\views/index.blade.php ENDPATH**/ ?>