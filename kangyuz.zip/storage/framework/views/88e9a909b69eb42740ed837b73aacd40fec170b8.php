<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>
<style>

    body{
        background-color: #2d3436
    }

    .images {
        width: 50%;
        /* height: 50%; */
    }

    .center {
        text-align: center !important;
    }

    .nameof {
        font-weight: bold;
        font-size: 30px
    }

    .count-task {
        text-align: center !important;
        font-size: 60px;
        background-color: #dfe4ea;
        color: #2f3542;
        font-weight: bolder
    }
    .count-task-medium {
        text-align: center !important;
        font-size: 60px;
        background-color: #ffa502;
        color: #ffffff;
        font-weight: bolder
    }
    .count-task-danger {
        text-align: center !important;
        font-size: 60px;
        background-color: #eb3b5a;
        color: #ffffff;
        font-weight: bolder
    }

    .job-title {
        color: #ffffff;
        font-size: 18px;
        margin-top: -10px;
        text-align: center !important;
        margin-bottom: 20px;
    }

    .bg-green {
        background-color: #78e08f;
        padding: 3px;
        border-radius: 5px;
    }

    .rank-1 {
        background-color: #f6b93b;
        padding: 0px;
        border-radius: 6px;
    }

    .rank-2 {
        background-color: #45aaf2;
        padding: 0px;
        border-radius: 6px;
    }

    .rank-3 {
        background-color: #a55eea;
        padding: 0px;
        border-radius: 6px;
    }

    .number {
        font-size: 50px;
        text-align: center !important;
        font-weight: bolder;
        color: white;
    }

    .description {
        margin-top: -10px;
        color: #4b6584
    }

    .project-name {
        font-weight: 100;
    }

    .project-name-blue {
        background-color: #dfe6e9;
        padding: 3px;
        color: #2f3542;
        border-radius: 4px;
        padding-left: 10px;
        padding-right: 10px;
    }
</style>

<body>
    <audio id="myAudio">
        <source src="<?php echo e(asset('sound/cute_notification.mp3')); ?>" type="audio/mpeg">
        Your browser does not support the audio element.
    </audio>
    <div class="container-fluid">
        <!-- content header -->
        <div class="row">

            <div class="col-md-6 content-score-task">
                <?php $__currentLoopData = $html_score_task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mt-3">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-1">
                                    <div class="rank-<?php echo e(($key + 1)); ?>">
                                        <h3 class="number">
                                            <?php echo e(($key + 1)); ?>

                                        </h3>
                                    </div>
                                </div>
                                <div class="col-md-10">
                                    <div class="people-of-rank">
                                        <h3>
                                            <?php echo e($item['name']); ?>

                                            <span class="project-name">- <?php echo e($item['project_name']); ?></span>
                                        </h3>
                                    </div>
                                    <div class="description">
                                        Mengerjakan <?php echo e($item['count_task']); ?> list hari ini!
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="col-md-6">
                <div class="mt-3">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead class="table-dark">
                                    <tr>
                                        <th width="25%">
                                            Nama Project
                                        </th>
                                        <th>
                                            Total Pekerjaan
                                        </th>
                                        <th>
                                            Selesai
                                        </th>
                                        <th>
                                            Programmer
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="marquee tbody-list-project">
                                    <?php $__currentLoopData = $html_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <b class="project-name-blue">
                                                    <?php echo e($item['project_name']); ?>

                                                </b>
                                            </td>
                                            <td>
                                                <?php echo e($item['all_task']); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item['finished_task']); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item['name']); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- list job -->
        <div class="row content-task">

                <?php $__currentLoopData = $html_task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class='col-md-3 p-3'>
                    <div class='card'>
                        <div class='card-body'>
                            <div class='profile-header'>
                                <div class='row'>
                                    <p class='center nameof'>
                                        <?php echo e($data['name']); ?>

                                    </p>
                                    <span class='job-title'>
                                        <b class='bg-green'><?php echo e($data['project_name']); ?></b>
                                    </span>
                                </div>
                            </div>
                            <div class='<?php echo e($data['class_count']); ?>'>
                                <?php echo e($data['count']); ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>
<script src="<?php echo e(asset('js/jquery-3.6.1.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('js/app.js')); ?>"></script>
<!-- Pusher -->
<script>
    $(function() {
        const Echo = window.Echo;

        var sound = document.getElementById("myAudio");
        let channel = Echo.channel('channel-task');

        channel.listen('TaskEvent', function(data) {

            console.log(data);
            
            $('.content-task').html('');
            $('.content-score-task').html('');
            $('.tbody-list-project').html('');

            var html_task   = "";
            var class_count = "";
            $.each(data.task.html_task, function(key, value) {

                html_task += `<div class='col-md-3 p-3'>
                                    <div class='card'>
                                        <div class='card-body'>
                                            <div class='profile-header'>
                                                <div class='row'>
                                                    <p class='center nameof'>
                                                        ${value.name}
                                                    </p>
                                                    <span class='job-title'>
                                                        <b class='bg-green'>${value.project_name}</b>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class='${value.class_count}'>
                                                ${value.count}
                                            </div>
                                        </div>
                                    </div>
                                </div>`;
            });

            var list_project = "";
            $.each(data.task.html_project, function(key, value) {

                list_project += `<tr>
                                        <td>
                                            <b class="project-name-blue">${value.project_name}</b>
                                        </td>
                                        <td>
                                            ${value.all_task}
                                        </td>
                                        <td>
                                            ${value.finished_task}
                                        </td>
                                        <td>
                                            ${value.name}
                                        </td>
                                    </tr>`;
            });

            var score_task = "";
            $.each(data.task.html_score_task, function(key, value) {

                score_task += `<div class="card mt-3">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <div class="rank-${key + 1}">
                                                <h3 class="number">
                                                    ${key + 1}
                                                </h3>
                                            </div>
                                        </div>
                                        <div class="col-md-10">
                                            <div class="people-of-rank">
                                                <h3>
                                                    ${value.name}
                                                    <span class="project-name">- ${value.project_name}</span>
                                                </h3>
                                            </div>
                                            <div class="description">
                                                Mengerjakan ${value.count_task} list hari ini!
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>`;
            });
            
            $('.content-task').append(html_task);
            $('.content-score-task').html(score_task);
            $('.tbody-list-project').append(list_project);

            sound.play();
        });

    });
</script>

</html>
<?php /**PATH C:\xampp\htdocs\kangyuz\resources\views/frontend/home.blade.php ENDPATH**/ ?>