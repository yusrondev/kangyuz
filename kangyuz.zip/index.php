<?php

header('Location:public/');